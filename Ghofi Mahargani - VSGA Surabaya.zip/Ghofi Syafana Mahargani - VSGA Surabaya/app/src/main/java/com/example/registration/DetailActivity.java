package com.example.registration;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.registration.data.DBHelper;
import com.example.registration.data.User;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;


public class DetailActivity extends AppCompatActivity {
    private  User user;
    private ImageView imagePreview;
    private TextView name;
    private TextView phone;
    private TextView gender;
    private TextView location;
    private TextView address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        DBHelper db = new DBHelper(getBaseContext());

        int userId = getIntent().getIntExtra("user_id", 0);

        user = db.get(userId);

        imagePreview = findViewById(R.id.image_preview);
        name = findViewById(R.id.name);
        phone = findViewById(R.id.phone);
        gender = findViewById(R.id.gender);
        location = findViewById(R.id.location);
        address = findViewById(R.id.address);

        try {
            ContextWrapper cw = new ContextWrapper(getApplicationContext());
            File directory = cw.getDir("imageDir", Context.MODE_PRIVATE);
            File f = new File(directory, user.getImage());

            Bitmap b = BitmapFactory.decodeStream(new FileInputStream(f));

            imagePreview.setImageBitmap(b);
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }

        name.setText(user.getName());
        phone.setText(user.getPhone());
        gender.setText(user.getGender());
        location.setText(user.getLocation());
        address.setText(user.getAddress());
    }

}