package com.example.registration;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ListView;

import com.example.registration.data.DBHelper;
import com.example.registration.data.User;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;


public class MainActivity extends AppCompatActivity {

    private ExtendedFloatingActionButton addFab;

    private ListView usersList;

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView imageView = findViewById(R.id.image_preview);
        usersList = findViewById(R.id.main_list);
        DBHelper db = new DBHelper(getBaseContext());

        User[] users = db.getAll().toArray(new User[0]);
        UserArrayAdapter adapter = new UserArrayAdapter(this, users);
        usersList.setAdapter(adapter);


        usersList.setOnItemClickListener((adapterView, view, i, l) -> {
            openDetail(users[i]);
        });

        addFab = findViewById(R.id.add_fab);

        addFab.setOnClickListener(view -> {
            Intent intent = new Intent(this, CreateActivity.class);
            startActivity(intent);
        });
    }

    private void openDetail(User user) {
        Intent intent = new Intent(this, DetailActivity.class);
        intent.putExtra("user_id", user.getId());
        startActivity(intent);
    }

}