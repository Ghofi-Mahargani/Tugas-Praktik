package com.example.registration.data;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "Registration.db";
    public static final String TABLE = "users";
    public static final String COLUMN_ID        = "id";
    public static final String COLUMN_NAME      = "name";
    public static final String COLUMN_ADDRESS   = "address";
    public static final String COLUMN_PHONE     = "phone";
    public static final String COLUMN_GENDER    = "gender";
    public static final String COLUMN_LOCATION  = "location";
    public static final String COLUMN_IMAGE     = "image";

    public DBHelper(@Nullable Context context) {
        super(context, DB_NAME, null, 1);
    }



    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable =
                "CREATE TABLE " + TABLE +" ("
                        + COLUMN_ID +" INTEGER PRIMARY KEY,"
                        + COLUMN_NAME + " TEXT,"
                        + COLUMN_ADDRESS + " TEXT,"
                        + COLUMN_PHONE + " TEXT,"
                        + COLUMN_GENDER + " TEXT,"
                        + COLUMN_LOCATION + " TEXT,"
                        + COLUMN_IMAGE + " TEXT)";

        db.execSQL(createTable);
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE );
        onCreate(db);
    }

    public void insert(User user) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_NAME, user.getName());
        contentValues.put(COLUMN_ADDRESS, user.getAddress());
        contentValues.put(COLUMN_PHONE, user.getPhone());
        contentValues.put(COLUMN_GENDER, user.getGender());
        contentValues.put(COLUMN_LOCATION, user.getLocation());
        contentValues.put(COLUMN_IMAGE, user.getImage());

        db.insert(TABLE, null,contentValues);
    }


    @SuppressLint("Range")
    private User parseUser(Cursor rawQuery) {
        int userId       = rawQuery.getInt(rawQuery.getColumnIndex(COLUMN_ID));
        String userName      = rawQuery.getString(rawQuery.getColumnIndex(COLUMN_NAME));
        String userAddress   = rawQuery.getString(rawQuery.getColumnIndex(COLUMN_ADDRESS));
        String userPhone     = rawQuery.getString(rawQuery.getColumnIndex(COLUMN_PHONE));
        String userGender    = rawQuery.getString(rawQuery.getColumnIndex(COLUMN_GENDER));
        String userLocation  = rawQuery.getString(rawQuery.getColumnIndex(COLUMN_LOCATION));
        String userImage     = rawQuery.getString(rawQuery.getColumnIndex(COLUMN_IMAGE));

        User user = new User(userName, userAddress,
                userPhone, userGender,
                userLocation, userImage);
        user.setId(userId);
        return user;
    }

    public User get(int id) {
        SQLiteDatabase db = getReadableDatabase();
        String query = String.format("SELECT * FROM %s WHERE %s LIKE '%d'",
                TABLE, COLUMN_ID, id);
        Cursor rawQuery = db.rawQuery(query, null);
        rawQuery.moveToFirst();

        User user = parseUser(rawQuery);

        return user;
    }


    public List<User> getAll() {
        List<User> users = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String query = String.format("SELECT * FROM %s", TABLE);
        Cursor rawQuery = db.rawQuery(query, null);
        rawQuery.moveToFirst();

        while (! rawQuery.isAfterLast()) {
            users.add(parseUser(rawQuery));
            rawQuery.moveToNext();
        }

        return users;
    }

}
