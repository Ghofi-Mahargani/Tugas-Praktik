package com.example.registration;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.registration.data.User;


public class UserArrayAdapter extends ArrayAdapter<User>{
    private final Activity context;
    private final User[] users;

    public UserArrayAdapter(@NonNull Activity context,
                               @NonNull User[] users) {
        super(context, R.layout.activity_list, users);

        this.context = context;
        this.users = users;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View rowView = inflater.inflate(R.layout.activity_list, null, true);

        TextView titleText = rowView.findViewById(R.id.title);
        TextView subtitleText = rowView.findViewById(R.id.subtitle);
        TextView extrasubtitleText = rowView.findViewById(R.id.extrasubtitle);

        titleText.setText(users[position].getName());
        subtitleText.setText(users[position].getGender());
        extrasubtitleText.setText(users[position].getLocation());

        return rowView;
    }

}
